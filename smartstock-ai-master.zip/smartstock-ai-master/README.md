# SmartStock AI 📈

An AI-powered stock analysis tool with a Node.js backend and clean HTML/CSS/JS frontend.

---

## 📁 Project Structure

```
smartstock-ai/
├── backend/
│   ├── server.js       ← Express API server (fixed)
│   └── package.json    ← Dependencies
├── frontend/
│   └── index.html      ← Frontend UI (open in browser)
└── README.md
```

---

## 🚀 How to Run

### Step 1 — Start the Backend

```bash
cd backend
npm install
npm start
```

You should see:
```
✅ Server running on http://localhost:5000
```

### Step 2 — Open the Frontend

Just open `frontend/index.html` in your browser:
- Double-click the file, OR
- Drag it into Chrome/Firefox

No build step needed.

---

## 🔌 API Reference

### `POST /api/analyze`

**Request:**
```json
{ "stock": "AAPL" }
```

**Response:**
```json
{
  "stock": "AAPL",
  "trend": "BUY",
  "trendIcon": "📈",
  "reason": "Stock is oversold (RSI < 30). This may be a good entry point.",
  "rsi": 24,
  "volatility": "3.42%",
  "marketCap": "$387B",
  "peRatio": "18.4",
  "dividendYield": "1.23%",
  "beta": "1.12",
  "week52High": "$198.45",
  "week52Low": "$134.22",
  "volume": "23.5M"
}
```

---

## 🐛 Bugs Fixed

| # | Location | Bug | Fix |
|---|----------|-----|-----|
| 1 | `server.js` | `app.listen()` was nested **inside** the POST route handler | Moved it outside to top level |
| 2 | `server.js` | `/api/analyze` route had no response — `res.json(...)` was missing | Added `res.json(analyzeStock(stock))` |
| 3 | `server.js` | Missing closing `}` for the route handler | Added proper closing braces |
| 4 | `index.html` | No error handling if backend is unreachable | Added try/catch with user-friendly error message |
| 5 | `index.html` | No loading state on button | Added spinner + disabled state |

---

## ⚠️ Disclaimer

This tool is for **educational purposes only** and does not provide real financial data or advice.
