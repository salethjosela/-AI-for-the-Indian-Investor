const express = require("express");
const cors = require("cors");
const app = express();

app.use(cors());
app.use(express.json());

/**
 * AI-like Analysis Logic
 */
function analyzeStock(stock) {
  const rsi = Math.floor(Math.random() * 100);
  const volatility = (Math.random() * 10).toFixed(2);

  let trend = "HOLD";
  let reason = "Stable trend with no strong buy or sell signals detected.";
  let trendIcon = "⚖️";

  if (rsi < 30) {
    trend = "BUY";
    reason = "Stock is oversold (RSI < 30). This may be a good entry point.";
    trendIcon = "📈";
  } else if (rsi > 70) {
    trend = "SELL";
    reason = "Stock is overbought (RSI > 70). Risk of price correction ahead.";
    trendIcon = "📉";
  }

  return {
    stock: stock.toUpperCase(),
    trend,
    trendIcon,
    reason,
    rsi,
    volatility: volatility + "%",
    marketCap: "$" + (Math.random() * 500 + 100).toFixed(0) + "B",
    peRatio: (Math.random() * 20 + 10).toFixed(1),
    dividendYield: (Math.random() * 3).toFixed(2) + "%",
    week52High: "$" + (Math.random() * 200 + 100).toFixed(2),
    week52Low: "$" + (Math.random() * 50 + 20).toFixed(2),
    volume: (Math.random() * 50 + 1).toFixed(1) + "M",
    beta: (Math.random() * 2 + 0.5).toFixed(2),
  };
}

/**
 * API Route - POST /api/analyze
 */
app.post("/api/analyze", (req, res) => {
  const { stock } = req.body;

  if (!stock || stock.trim() === "") {
    return res.status(400).json({ error: "Stock symbol is required." });
  }

  const result = analyzeStock(stock.trim());
  res.json(result);
});

/**
 * Health check route
 */
app.get("/", (req, res) => {
  res.json({ message: "SmartStock AI Backend is running 🚀" });
});

// ✅ app.listen is OUTSIDE the route — this was the original bug
app.listen(5000, () => {
  console.log("✅ Server running on http://localhost:5000");
});
